import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms'
@Component({
  selector: 'app-endorsement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './endorsement.component.html',
  styleUrl: './endorsement.component.scss'
})
export class EndorsementComponent {

  options: string[] = ['Option 1', 'Option 2', 'Option 3'];
  selectedOption: string = '';

  addOption() {
    const newOption = prompt('Enter new option:');
    if (newOption) {
      this.options.push(newOption);
    }
  }

  generateQuote() {
    if (this.selectedOption) {
      console.log(`Generating quote for ${this.selectedOption}`);
    } else {
      alert('Please select an option first!');
    }
  }
}


