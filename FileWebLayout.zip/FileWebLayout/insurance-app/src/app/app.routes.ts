import { Routes } from '@angular/router';
import { provideRouter } from '@angular/router';
import { InsurancePremiumComponent } from './insurance-premium/insurance-premium.component';
import { OptionsComponent } from './options/options.component';
import { EndorsementComponent } from './endorsement/endorsement.component';

export const routes: Routes = [
    {path:'', component: InsurancePremiumComponent},
    {path:'options', component: OptionsComponent},
    {path:'endorsement', component: EndorsementComponent}
];

