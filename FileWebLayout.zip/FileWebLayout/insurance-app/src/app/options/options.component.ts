import { Component } from '@angular/core';
import { RouterModule, Router} from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-options',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './options.component.html',
  styleUrl: './options.component.scss'
})
export class OptionsComponent {
  options = [{id:1}, {id:2}, {id:3}];

  constructor(private router: Router) {}

  addEndorsement(){
    this.options.push({id: this.options.length + 1})
  }

  save(){
    this.router.navigate(['/endorsement']);
  }
}
