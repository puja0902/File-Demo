import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Exposure{
  percentage: string;
  id: number;
  premium: number;
}

@Component({
  selector: 'app-insurance-premium',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './insurance-premium.component.html',
  styleUrl: './insurance-premium.component.scss'
})
export class InsurancePremiumComponent {
  basePremium = 5000;
  modifiedPremium = 4321.87;

  exposureData: Exposure[] = [
    {percentage: '100%', id: 111, premium:500},
    {percentage: '80%', id: 112, premium:1000},
    {percentage: '70%', id: 211, premium:1030},
  ];

  modFactors ={
    quantitative: 88.75,
    qualitative: 95
  };

  calculateTotalPremium(){
    let totalExposurePremium = 0;
    this.exposureData.forEach(exposure => {
      totalExposurePremium += exposure.premium;
    });

    let adjustedPremium = this.basePremium+totalExposurePremium

    adjustedPremium *= (this.modFactors.quantitative/100);
    adjustedPremium *= (this.modFactors.qualitative/100);

    this.modifiedPremium = adjustedPremium
  }

  addExposure(){
   const newExposure: Exposure ={
    percentage: '90%',
    id: this.generateUniqueId(),
    premium: 750
   };
   this.exposureData.push(newExposure);
   this.calculateTotalPremium()
  }

  removeExposure(){
    if(this.exposureData.length> 0){
      this.exposureData.pop();
      this.calculateTotalPremium()
    }
  }

  private generateUniqueId(): number {
    return Math.floor(Math.random() * 1000)
  }
}
